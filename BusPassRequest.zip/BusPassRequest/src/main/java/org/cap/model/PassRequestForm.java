package org.cap.model;

import java.time.LocalDate;

public class PassRequestForm {

	private Integer requestId;
	private String employeeId;
	private String firstName;
	private String lastName;
	private String gender;
	private String address;
	private String email;
	private LocalDate dateOfJoining;
	private String location;
	private String pickUpLocation;
	private String pickUpTime;
	private String designation;
	private String status;
	
	public PassRequestForm() {
		super();
	}
	public PassRequestForm(Integer requestId, String employeeId, String firstName, String lastName, String gender,
			String address, String email, LocalDate dateOfJoining, String location, String pickUpLocation,
			String pickUPTime) {
		super();
		this.requestId = requestId;
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.address = address;
		this.email = email;
		this.dateOfJoining = dateOfJoining;
		this.location = location;
		this.pickUpLocation = pickUpLocation;
		this.pickUpTime = pickUpTime;
		
	}
	public PassRequestForm(String designation, String status) {
		super();
		this.designation = designation;
		this.status = status;
	}
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPickUpLocation() {
		return pickUpLocation;
	}
	public void setPickUpLocation(String pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}
	public String getPickUPTime() {
		return pickUpTime;
	}
	public void setPickUPTime(String pickUPTime) {
		this.pickUpTime = pickUpTime;
	}
	@Override
	public String toString() {
		return "PassRequestForm [requestId=" + requestId + ", employeeId=" + employeeId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", gender=" + gender + ", address=" + address + ", email=" + email
				+ ", dateOfJoining=" + dateOfJoining + ", location=" + location + ", pickUpLocation=" + pickUpLocation
				+ ", pickUPTime=" + pickUpTime + "]";
	}
	
	
	
}
