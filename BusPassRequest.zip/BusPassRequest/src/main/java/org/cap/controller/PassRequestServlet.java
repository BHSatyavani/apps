package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.PassRequestForm;

@WebServlet("/PassRequestServlet")
public class PassRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public PassRequestServlet() {
		super();

	}




	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String employeeId=request.getParameter("employeeId");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String gender=request.getParameter("gender");
		String address=request.getParameter("address");
		String email=request.getParameter("email");
		String  dateOfJoining=request.getParameter("dateOfJoining");
		String location=request.getParameter("location");
		String pickUpLocation=request.getParameter("pickUpLocation");
		String  pickUpTime=request.getParameter(" pickUpTime");
		
		PassRequestForm requestform=new PassRequestForm();
		requestform.setEmployeeId(employeeId);
		requestform.setFirstName(firstName);
		requestform.setLastName(lastName);
		requestform.setGender(gender);
		requestform.setAddress(address);
		requestform.setEmail(email);
		requestform.setDateOfJoining(dateOfJoining);
		requestform.setLocation(location);
		requestform.setPickUpLocation(pickUpLocation);
		requestform.setpickUpTime(pickUpTime);
	
		
		
		
	}

}
