package com.bvk.dao;

import com.bvk.entity.EmployeeTO;

public interface EmployeeDAO {
	int insertUsingProcedure(EmployeeTO employeeTO);
	float getSalary(int empid);
	float getSalaryByFunction(int empid);
}
