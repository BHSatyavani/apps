package com.bvk.client;

import java.util.Scanner;

import com.bvk.dao.CustomerDAO;
import com.bvk.dao.CustomerDAOImpl;
import com.bvk.entity.CustomerTO;

public class ClientCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scInput = new Scanner(System.in);
		
		int custId;
		String name;
		String address;
		
		CustomerTO customerTO = null;
		CustomerDAO customer = new CustomerDAOImpl();
		
		System.out.print("Enter custid: ");
		custId = scInput.nextInt();
				 scInput.nextLine();
				 
		System.out.print("Enter Name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter Address: ");
		address = scInput.nextLine();
		
		customerTO = new CustomerTO(custId, name, address);
		
		int status = customer.insertCustomer(customerTO);
		
		if(status == 1){
			System.out.println("Record inserted..");
		}else{
			System.out.println("Unable to insert record..");
		}
	}
}