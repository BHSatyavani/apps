package com.capgemini;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * 
 * servlet implementation class DemoServlet
 *
 */
@WebServlet(urlPatterns= {"/DemoServlet","/hello"},initParams=
		 		{@WebInitParam(name="driverClass",value="com.mysql.jdbc.Driver"),
		 		@WebInitParam(name="userName",value="root"),
				@WebInitParam(name="password",value="India123")


		 }) 
			  
public class DemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 String driverClassName,userName,password;
 ServletContext context=getServletContext();
 
 @Override
   public void init(ServletConfig config) throws ServletException{
	 driverClassName=config.getInitParameter("driverClass");
 }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		ServletConfig config=getServletConfig();
		
		String email=context.getInitParameter("email");
	    response.getWriter().println("<h1> Email:"+email+"</h1>");
	    
	    String greet=context.getInitParameter("greetings");
	    response.getWriter().println("<h1> Greetings:"+greet+"</h1>");
	    
	    response.getWriter().println("<h1> Driver Class Name"+driverClassName+"</h1>");
	    
	    
		
	}

}
