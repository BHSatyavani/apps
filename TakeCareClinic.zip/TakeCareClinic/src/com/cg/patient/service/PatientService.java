package com.cg.patient.service;

import com.cg.patient.bean.Patient;
import com.cg.patient.exception.PatientException;

public interface PatientService {
	boolean validateDetails(Patient details) throws PatientException;
	public int addPatientInformation(Patient request) throws PatientException;
	Patient searchPatientById(int id) throws PatientException;
}
