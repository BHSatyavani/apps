package com.cg.patient.service;

import com.cg.patient.bean.Patient;
import com.cg.patient.dao.PatientDao;
import com.cg.patient.dao.PatientDaoImpl;
import com.cg.patient.exception.PatientException;

public class PatientServiceImpl implements PatientService {
	PatientDao patientDao=new PatientDaoImpl();
	@Override
	public boolean validateDetails(Patient details) throws PatientException {
		if(validateName(details.getName()) && validatePhone(details.getPhone()) && validateAge(details.getAge())
				&& validateDescription(details.getDescription())){
			return true;
		}
		return false;
	}
	private boolean validateName(String name) throws PatientException{
		if(name.isEmpty()||name==null) {
			throw new PatientException("Patient Name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z ]{2,}")) {
				throw new PatientException("Patient Name should start with a Capital letter and should be of minimum 3 alphabets");
			}
		}
		return true;
	}
	private boolean validateAge(String age) throws PatientException{
		
		if(age.isEmpty()||age==null) {
			throw new PatientException("Patient Age cannot be empty");
		}
		else {
			if(age.matches("[A-Za-z]{1,}")) {
				throw new PatientException("Patient Age is not valid");
			}
			else {
				int a=Integer.parseInt(age);
				if(a<0 || a>120) {
				throw new PatientException("Patient Age is not valid");
				}
			}
		}
		return true;
	}
	private boolean validatePhone(String phone) throws PatientException{
		if(phone.isEmpty()||phone==null) {
			throw new PatientException("Phone Number cannot be empty");
		}
		else {
			if(!phone.matches("\\d{10}")) {
				throw new PatientException("Phone Number should be 10 digits");
			}
		return true;
	}
	}
	private boolean validateDescription(String description) throws PatientException{
		if(description.isEmpty()||description==null) {
			throw new PatientException("Description cannot be empty");
		}
		else {
			if(!description.matches("[A-Za-z0-9., ]{1,}")) {
				throw new PatientException("Enter valid description. Description should not contain any special characters");
			}
		return true;
	}
	}
	@Override
	public int addPatientInformation(Patient request) throws PatientException {
		return patientDao.addPatientInformation(request);
	}
	@Override
	public Patient searchPatientById(int id) throws PatientException {
		return patientDao.searchPatientById(id);
		
	}

}
