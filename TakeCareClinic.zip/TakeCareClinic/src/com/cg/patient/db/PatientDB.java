package com.cg.patient.db;

import java.util.HashMap;

import com.cg.patient.bean.Patient;

public class PatientDB {
	private static HashMap<Integer,Patient> PatientMap=new HashMap<Integer,Patient>();

	public static HashMap<Integer, Patient> getPatientMap() {
		return PatientMap;
	}
}
