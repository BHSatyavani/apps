package com.cg.patient.dao;

import java.util.HashMap;
import java.util.Optional;
import com.cg.patient.bean.Patient;
import com.cg.patient.db.PatientDB;
import com.cg.patient.exception.PatientException;

public class PatientDaoImpl implements PatientDao {
	static HashMap<Integer,Patient> PatientMap=PatientDB.getPatientMap();
	
	@Override
	public int addPatientInformation(Patient request) throws PatientException {
			try{
				if(PatientMap.size()==0) {      
					request.setPatientId(5001);
				}
				else {
					Optional<Integer> id=PatientMap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
					int reqid=id.get()+1;
					request.setPatientId(reqid);
				}
				PatientMap.put(request.getPatientId(), request);
				return request.getPatientId();
			}
			
				catch(Exception ex) {
					throw new PatientException(ex.getMessage());
				}
				
	}
	@Override
	public Patient searchPatientById(int id) throws PatientException {
		try {
			Patient patient=PatientMap.get(id);
			if(patient==null) {
				throw new PatientException("Patient with the Id "+id+" Not availabe in the database");
			}
			return patient;
			}
			catch(Exception ex) {
				throw new PatientException(ex.getMessage());
			}
	}
}
	
