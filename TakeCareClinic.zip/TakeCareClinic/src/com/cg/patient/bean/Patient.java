package com.cg.patient.bean;

import java.time.LocalDate;

public class Patient {
	private int patientId;
	private String name;
	private String age;
	private String phone;
	private String description;
	private LocalDate consulationDate;
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDate getConsulationDate() {
		return consulationDate;
	}
	public void setConsulationDate(LocalDate consulationDate) {
		this.consulationDate = consulationDate;
	}
	
}
