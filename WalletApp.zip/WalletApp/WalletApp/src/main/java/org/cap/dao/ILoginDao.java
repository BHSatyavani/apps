package org.cap.dao;

public interface ILoginDao {

//	@Override
	//public boolean validateLogin(int customerId ,String custPwd) {
// false;
//	}
}
