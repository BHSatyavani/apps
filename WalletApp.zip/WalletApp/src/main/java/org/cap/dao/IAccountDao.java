package org.cap.dao;

import org.cap.model.Account;

public interface IAccountDao {

	public void createAccount(Account account);
}
