package org.cap.service;

import org.cap.model.Account;

public interface IAccountService {

	void createAccount(Account account);

}
