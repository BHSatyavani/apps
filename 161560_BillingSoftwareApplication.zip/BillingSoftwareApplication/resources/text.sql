create table product(product_code number primary key,product_name varchar2(20),product_category varchar2(20),product_description varchar2(30),product_price number);


insert into product values(1001,'iphone','electronics','smart phone',35000);
insert into product values(1002,'ledtv','electronics','tv',45000);
insert into product values(1003,'teddy','toys','soft toy',800);
insert into product values(1004,'pencil','stationary','a pack of 12 pencils',80);

create table sales(sales_id number,product_code number references product(product_code),quantity number,sales_date date,line_total number);
CREATE SEQUENCE sales_id START WITH 1001;