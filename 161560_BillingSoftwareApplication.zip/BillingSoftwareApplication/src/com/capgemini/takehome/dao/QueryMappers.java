package com.capgemini.takehome.dao;

public interface QueryMappers {
	public static final String selectQuery = "select * from product where product_code=?";
	public static final String salesQuery="insert into sales values(sales_id.NEXTVAL,?,?,sysdate,?)";
}
