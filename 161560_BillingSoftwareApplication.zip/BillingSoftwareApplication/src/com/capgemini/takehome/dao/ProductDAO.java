package com.capgemini.takehome.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.takehome.Exception.TakeHomeException;
import com.capgemini.takehome.bean.ProductBean;
import com.capgemini.takehome.utility.JdbcUtility;




public class ProductDAO implements IProductDAO {
	static Logger logger = Logger.getLogger(ProductDAO.class);
	Connection connection = null;
	PreparedStatement statement = null;
	PreparedStatement statement2 = null;
	
	@Override
	public ProductBean getProductByCode(ProductBean productBean)
			throws TakeHomeException {
logger.info("in getProductByCode method..");

		
		connection = JdbcUtility.getConnection();
		ProductBean p;
		try{
	
			statement = connection.prepareStatement(QueryMappers.selectQuery);
			
			statement.setInt(1, productBean.getProduct_code());
	
			
			
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
			
				
				productBean.setProduct_name(resultSet.getString(2));
				productBean.setProduct_category(resultSet.getString(3));
				productBean.setProduct_description(resultSet.getString(4));
				productBean.setProduct_price(resultSet.getDouble(5));
				//System.out.println(p);
				statement2 = connection.prepareStatement(QueryMappers.salesQuery);
				statement2.setInt(1, productBean.getProduct_code());
				statement2.setInt(2,productBean.getQuantity() );
				statement2.setDouble(3,((productBean.getQuantity())*productBean.getProduct_price())) ;
				statement2.executeUpdate();
			return productBean;
			
		
	}catch(SQLException e)
		{logger.error("statement not created..");
		
		throw new TakeHomeException("statement not created");
		}
	}
}
	
	
	

