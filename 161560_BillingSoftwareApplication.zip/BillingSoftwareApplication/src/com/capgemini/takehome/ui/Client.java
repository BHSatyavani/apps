package com.capgemini.takehome.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.takehome.bean.ProductBean;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;




public class Client {

	static Logger logger = Logger.getLogger(Client.class);

	public static void main(String[] args) {
		ProductBean productBean=new ProductBean();

		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file loaded...");
		IProductService service = new ProductService();
		Scanner scanner = new Scanner(System.in);
		System.out.println("welcome to  Billing software Applicatuion");
		
		System.out.println("1.	Generate Bill by entering Product code and quantity");
		System.out.println("2.  Exit");
		System.out.println("Select ur choice");
		int choice = 0;
		try {
			choice = scanner.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("enter only digits");
			System.exit(0);
		}
		switch(choice){
		
		case 1:
			int code=0;
		int quantity=0;
			try{
				System.out.println("Enter Product code:");
				code=scanner.nextInt();
				productBean.setProduct_code(code);
			}catch(InputMismatchException e)
			{
				e.printStackTrace();
				
			}
			try{
				System.out.println("Enter Quantity:");
				quantity=scanner.nextInt();
				productBean.setQuantity(quantity);
			}catch(InputMismatchException e)
			{
				e.printStackTrace();
				
			}
			
			try{
				
		 productBean = service.getProductBycode(productBean);
				System.out.println("---------------------");
				System.out.println("Product Name:  " + productBean.getProduct_name());
				System.out.println("Product Category: " + productBean.getProduct_category());
				System.out.println("Product Description:" + productBean.getProduct_description());
				System.out.println("Product Price (Rs): " + productBean.getProduct_price());
				System.out.println("Quantity: " + quantity);
				System.out.println("Line Total (Rs):  " + ((productBean.getQuantity())*productBean.getProduct_price()));
			} catch (Exception e) {
				System.err.println(e.getMessage());
			}
		
		break;
		case 2: System.exit(0);
		}
}
}
