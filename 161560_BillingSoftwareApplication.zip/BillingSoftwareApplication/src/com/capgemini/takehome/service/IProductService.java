package com.capgemini.takehome.service;

import com.capgemini.takehome.Exception.TakeHomeException;
import com.capgemini.takehome.bean.ProductBean;



public interface IProductService {
	boolean validateDetails(ProductBean patient) throws TakeHomeException;





	public ProductBean getProductBycode(ProductBean productBean) throws TakeHomeException;
}
