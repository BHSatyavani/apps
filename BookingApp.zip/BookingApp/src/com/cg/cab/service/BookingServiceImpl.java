package com.cg.cab.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.cg.cab.bean.CabRequest;
import com.cg.cab.dao.BookingDao;
import com.cg.cab.dao.BookingDaoImpl;
import com.cg.cab.exception.BookingException;

public class BookingServiceImpl implements BookingService {
	BookingDao bookingDao=new BookingDaoImpl();
	@Override
	public boolean validateRequest(CabRequest request) throws BookingException {
		if(validateName(request.getCustomerName())&& validatePhone(request.getPhoneNumber())){
			return true;
		}
		return false;
	}
	private boolean validateName(String name) throws BookingException{
		if(name.isEmpty()||name==null) {
			throw new BookingException("Customer Name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new BookingException("Customer Name should start with a Capital letter and should be of minimum 3 alphabets");
			}
		}
		return true;
	}
	private boolean validatePhone(String phone) throws BookingException{
		if(phone.isEmpty()||phone==null) {
			throw new BookingException("Phone Number cannot be empty");
		}
		else {
			if(!phone.matches("\\d{10}")) {
				throw new BookingException("Phone Number should be 10 digits");
			}
		return true;
	}
	}
	@Override
	public int addRequest(CabRequest request) throws BookingException {
		try {
			FileInputStream fis=new FileInputStream("pincode.properties");
			Properties props=new Properties();
			props.load(fis);
			String cabno=props.getProperty(request.getPincode());
			if(cabno!=null) {
				request.setCabNumber(cabno);
				request.setStatus("Accepted");
			}
			return bookingDao.addRequest(request);
		} catch (FileNotFoundException e) {
			throw new BookingException(e.getMessage());
		} catch (IOException e) {
			throw new BookingException(e.getMessage());
		}
		
	}
	@Override
	public CabRequest getRequest(int requestId) throws BookingException {
		return bookingDao.getRequest(requestId);
	}
}
