package org.cap.demo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
   
	@Id
	private int customerId;
	private String customerName;
	private Double regFee;
	private Date regDate;
		
	public Customer() {
		super();
	}

	public Customer(int customerId, String customerName, Double regFee, Date regDate) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.regFee = regFee;
		this.regDate = regDate;
		
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Double getRegFee() {
		return regFee;
	}

	public void setRegFee(Double regFee) {
		this.regFee = regFee;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", regFee=" + regFee
				+ ", regDate=" + regDate + "]";
	}
	

}
