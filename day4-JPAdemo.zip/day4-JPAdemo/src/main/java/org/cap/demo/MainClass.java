package org.cap.demo;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
	
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		Date now=new Date();
		Customer customer=new Customer(1001,"Satya",1500.00,now);
		Customer customer1=new Customer(1002,"Sree",1900.00,now);
		Customer customer2=new Customer(1003,"Mouni",1200.00,now);
		
		entityManager.persist(customer);
		entityManager.persist(customer1);
		entityManager.persist(customer2);
			
		transaction.commit();
		entityManager.close();
		

	}

}
