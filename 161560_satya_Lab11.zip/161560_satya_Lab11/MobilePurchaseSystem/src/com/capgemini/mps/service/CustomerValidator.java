package com.capgemini.mps.service;


import java.time.Period;
import java.util.regex.Pattern;

/**
 * 
 * @author sbhogapu
 *
 */
public class CustomerValidator {
	
	/**
	 * 
	 * @param customer
	 * @return true if customer name is a sequence of 20 alphabets
	 * and should begin with upper case letter else return false
	 */


	public Boolean isValidCustomerName(String name){
		String regex="^[A-Z][a-zA-Z\\s]{0,19}$";
		//System.out.println(name);
		return Pattern.matches(regex,name);
          //return true;
	}

	/**
	 * 
	 * @param emailId
	 * @return true if email is valid else return false.
	 */

	public Boolean isValidCustomerEmail(String emailId){
		
		String regex=/*"^[a-zA-Z0-9._]+@[a-zA-Z1-9]+.[a-zA-Z]{2,3}$"*/
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$" ;
		return Pattern.matches(regex,emailId);
	}
	
	/**
	 * 
	 * @param phoneNumber
	 * @return true if phone number is 10 digits
	 * else return false
	 */
	public Boolean isValidPhoneNumber(Long phoneNumber){
		String mobile=phoneNumber.toString();
		String regex="^[1-9][0-9]{9}$";
		return Pattern.matches(regex, mobile);
	}
}
