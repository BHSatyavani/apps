
package com.capgemini.mps.service;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.mps.bean.Mobile;
import com.capgemini.mps.dao.IPurchaseDAO;
import com.capgemini.mps.dao.MobileDaoImpl;
import com.capgemini.mps.dao.PurchaseDaoImpl;
import com.capgemini.mps.exception.MobilePurchaseSystemException;

public class PurchaseServiceImpl implements IPurchaseService{
	
	IPurchaseDAO purchaseDAO=new PurchaseDaoImpl();
	
	private static Logger ServiceLogger=Logger.getLogger(PurchaseServiceImpl.class);
	@Override
	public Integer addPurchaseDetails(String name,String emailId,Long phoneNumber, Integer mobileId) throws MobilePurchaseSystemException {
		try{
			
			Mobile mobile=new MobileDaoImpl().getMobileDetails(mobileId);
			System.out.println(mobile);
			if(mobile.getQuantity()>0){
				
				Integer purchaseId=purchaseDAO.addPurchaseDetails(name, emailId, phoneNumber, mobileId);
				//System.out.println("Service Layer:"+purchaseId);
				return purchaseId;
			}else{
				throw new MobilePurchaseSystemException("No Stock");
			}
			
		}catch(MobilePurchaseSystemException e){
			ServiceLogger.error(e);
			throw new MobilePurchaseSystemException("Techincal error... Contact to logs");
		}

	}
} 
 
