package com.capgemini.mps.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class CustomerValidatorTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIsValidCustomerName() {
		//fail("Not yet implemented");
		assertTrue(new CustomerValidator().isValidCustomerName("Satya Vani"));
	}

	@Test
	public void testIsNotValidCustomerName() {
		//fail("Not yet implemented");
	assertTrue(new CustomerValidator().isValidCustomerName("Satya Vani xxxxxxxxxxxx"));
	}

	@Test
	public void testIsValidCustomerEmail() {
		//fail("Not yet implemented");
	assertTrue(new CustomerValidator().isValidCustomerEmail("Satyavani@gmail.com"));
	}

	@Test
	public void testIsNotValidCustomerEmail() {
		//fail("Not yet implemented");
	assertTrue(new CustomerValidator().isValidCustomerEmail("Satya@vani@gmail.com"));
	}
	@Test
	public void testIsValidphoneNumber() {
		//fail("Not yet implemented");
	assertTrue(new CustomerValidator().isValidPhoneNumber(9247335332L));
	}
	
	
	@Test
	public void testIsNotValidphoneNumberMobile() {
		//fail("Not yet implemented");
	assertTrue(new CustomerValidator().isValidPhoneNumber(9247335332L));
	}

}
