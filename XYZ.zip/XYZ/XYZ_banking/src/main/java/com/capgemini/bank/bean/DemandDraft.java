package com.capgemini.bank.bean;

import java.time.LocalDate;

public class DemandDraft {
	
	private int transactionId;
	private LocalDate date;
	private int commission;
	private String customerName;
	private String mobile;
	private String inFavourOf;
	private double amount;
	private String description;
	
	//default empty argument constructor
	public DemandDraft() {
		
	}
	
	
	@Override
	public String toString() {
		return "DemandDraft [transactionId=" + transactionId + ", date=" + date + ", commission=" + commission
				+ ", customerName=" + customerName + ", mobile=" + mobile + ", inFavourOf=" + inFavourOf + ", amount="
				+ amount + ", description=" + description + "]";
	}


	public DemandDraft(int transactionId, LocalDate date, int commission, String customerName, String mobile,
			String inFavourOf, double amount, String description) {
		super();
		this.transactionId = transactionId;
		this.date = date;
		this.commission = commission;
		this.customerName = customerName;
		this.mobile = mobile;
		this.inFavourOf = inFavourOf;
		this.amount = amount;
		this.description = description;
	}


	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public LocalDate getDate() {
		return date;
	}


	public void setDate(LocalDate date) {
		this.date = date;
	}


	public int getCommission() {
		return commission;
	}


	public void setCommission(int commission) {
		this.commission = commission;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getInFavourOf() {
		return inFavourOf;
	}


	public void setInFavourOf(String inFavourOf) {
		this.inFavourOf = inFavourOf;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
