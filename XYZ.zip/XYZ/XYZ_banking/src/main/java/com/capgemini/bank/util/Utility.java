package com.capgemini.bank.util;

public class Utility {

	public static boolean isValidName(String name) {
		return name.matches("[a-zA-Z]{1}[a-z]{3,}");
	}
	
	
	public static boolean isValidMobile(String mobile) {
		return mobile.matches("[7-9]{1}[0-9]{9}");
	}
	
	public static boolean isValidInFavourOf(String inFavourOf) {
		return inFavourOf.matches("[A-Za-z.0-9]+");
	}
}
