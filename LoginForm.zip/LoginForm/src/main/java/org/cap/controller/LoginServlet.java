package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.LoginBean;
import org.cap.service.ILoginService;
import org.cap.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		
		LoginBean loginBean=new LoginBean(userName,userPwd);
		ILoginService iloginService=new LoginServiceImpl();
		
		if(iloginService.isValidLogin(loginBean)) {
			 response.sendRedirect("pages/success.html");
		}
		
		
	}	
}
		/*if(userName.equals("tom")&& userPwd.equals("tom123")) {
			response.sendRedirect("pages/success.html");
		}else {*/
			/*response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			out.println("UserName or Password is incorrect");
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			rd.include(request, response);*/
			//response.sendRedirect("index.html");
		//}
		
		
	/*	try {
			Class.forName("com.mysql.jdbc.Driver");
		 Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:8081/test","root","India123");
		 PreparedStatement preparedStatement=connection.prepareStatement("select * from LoginTable where UserName=? and Password=?");
		 preparedStatement.setString(1,userName);
		 preparedStatement.setString(2, userPwd);
		 ResultSet resultSet=preparedStatement.executeQuery();
		 while(resultSet.next()) {
			 if(userName.equals("tom")&& userPwd.equals("tom123")) {
				 response.sendRedirect("pages/success.html");
				 
			 }
			 
		 }
			
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	
		
	}*/


