package org.cap.dao;  
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.model.LoginBean;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		String sql="select * from LoginDetails where username=? and userpassword=?";

		try(PreparedStatement ps =getSQLConnection().prepareStatement(sql);){

			ps.setString(1, loginBean.getUserName());
			ps.setString(2, loginBean.getUserPswd());
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				return true;

			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	private Connection getSQLConnection()
	{
		Connection con=null;
		try{

			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mywork","root","India123");
			return con;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
		}

		return con;
	}
} 
 

