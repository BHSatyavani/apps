package org.cap.model;

public class LoginBean {
	private String userName;
	private String userPswd;
	
	public LoginBean(String userName, String userPswd) {
		super();
		
		this.userName = userName;
		this.userPswd = userPswd;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPswd() {
		return userPswd;
	}
	public void setUserPswd(String userPswd) {
		this.userPswd = userPswd;
	}
	@Override
	public String toString() {
		return "LoginBean [userName=" + userName + ", userPswd=" + userPswd + "]";
	}
	
	
	

}
