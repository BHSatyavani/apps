package org.cap.demo;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class DateFormat extends SimpleTagSupport{
	String format;
	LocalDate date =LocalDate.now();

	public void setFormat(String format) {
		this.format=format;
	}
	
	@Override
	public void doTag() throws JspException, IOException {
		
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MMM/yyyy");
		String text=date.format(formatter);	
		
		 JspWriter out= getJspContext().getOut();
			out.println("<h1>"+text+"</h1>");
		
	}

}
