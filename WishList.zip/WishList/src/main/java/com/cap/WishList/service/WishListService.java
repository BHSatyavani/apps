package com.cap.WishList.service;

import java.util.List;

import com.cap.WishList.modal.WishList;

public interface WishListService {

	public List<Integer> getAll(int custId);
	/*public List<WishList> deleteWishList(Integer wishId);
	public WishList getOne(Integer customerId)*/
	public WishList saveWish(WishList wishList);

}
