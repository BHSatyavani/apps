package com.cap.WishList.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.WishList.modal.Inventory;

@Repository
@Transactional
public interface InventoryDao extends JpaRepository<Inventory, Integer> {

}
